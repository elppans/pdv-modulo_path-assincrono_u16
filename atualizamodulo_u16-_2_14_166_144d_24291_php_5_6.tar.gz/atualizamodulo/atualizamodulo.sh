#!/bin/bash

LOC="$(pwd)"
DATE="$(date +%d%m%Y)"
DIRMOD="/Zanthus/Zeus/pdvJava/GERAL/SINCRO/WEB/moduloPHPPDV"
PDVIP="$(ifconfig eth0 | grep "inet " | awk '{print $2}')"

rm -rf /Zanthus/Zeus/path_comum_temp/*
rm -rf "$DIRMOD"/moduloPHPPDV*
cp -av "$LOC"/moduloPHPPDV* "$DIRMOD"/moduloPHPPDV.zip
unzip -o "$DIRMOD"/moduloPHPPDV.zip -d "$DIRMOD"

echo "Processo concluído com sucesso!"
echo "Confira se o modulo esta de pe no navegador: http://127.0.0.1:9090/moduloPHPPDV/info.php?key=50245869000174$DATE"
echo "Se estiver em outro computador, acesse: http://$PDVIP:9090/moduloPHPPDV/info.php?key=50245869000174$DATE"
echo


